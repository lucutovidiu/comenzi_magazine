<?php
/*
    Tabele Comenzi Magazine

    create table utilizatori(
        id                      int auto_increment not null primary key,
        nume_utilizator         varchar(40) unique not null,
        locatie_utilizator      varchar(60) not null,
        parola_utilizator       varchar(100) not null,
        ultima_logare           datetime
    )ENGINE = InnoDB; 

    create table articole(
        id                      int auto_increment not null primary key,
        nume_articol            varchar(100) unique not null,
        cantitate_stoc          int not null,
        pret                    float not null,
        status                  varchar(20) not null
    )ENGINE = InnoDB; 

    create table stare_comenzi(
        id                      int auto_increment not null primary key,
        nume_stare              varchar(40) unique not null
    )ENGINE = InnoDB; 

    create table comenzi(
        nr_comanda              int auto_increment not null primary key,
        id_utilizator           int not null,
        data_comanda            datetime not null,
        IDStare                 int not null,
        CONSTRAINT `comenzi_fk1` FOREIGN KEY (`id_utilizator`) REFERENCES `utilizatori` (`id`)
                ON UPDATE CASCADE,
        CONSTRAINT `comenzi_fk2` FOREIGN KEY (`IDStare`) REFERENCES `stare_comenzi` (`id`)
                ON UPDATE CASCADE
    )ENGINE = InnoDB; 

    

    create table detalii_comanda(
        id                      int auto_increment not null primary key,
        id_comenzi              int not null,
        id_articol              int not null,
        cantitate               int not null,
        CONSTRAINT detalii_comanda_fk1 FOREIGN KEY (id_comenzi) REFERENCES comenzi (nr_comanda)
                ON UPDATE CASCADE,
        CONSTRAINT detalii_comanda_fk2 FOREIGN KEY (id_articol) REFERENCES articole (id)
            ON UPDATE CASCADE  
    )
*/

?>